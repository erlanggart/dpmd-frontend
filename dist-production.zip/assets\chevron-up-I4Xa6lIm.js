import{b9 as o}from"./index-DuMqZyKO.js";/**
 * @license lucide-react v0.545.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",e);export{n as C};
