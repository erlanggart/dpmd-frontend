const t=()=>localStorage.getItem("expressToken")==="VPN_ACCESS_TOKEN";export{t as i};
