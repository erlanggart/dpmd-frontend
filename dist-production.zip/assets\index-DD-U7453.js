import{bi as r}from"./index-DuMqZyKO.js";var a=r();export{a as r};
